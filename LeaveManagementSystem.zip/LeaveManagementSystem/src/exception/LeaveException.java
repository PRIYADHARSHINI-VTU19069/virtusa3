package exception;

public class LeaveException extends Exception {

    public LeaveException() {
        super();
    }

    public LeaveException(String message) {
        super(message);
    }
}